package Testes;

import java.util.Arrays;

import classes.Ordenar;

public class Questao2 {
	Ordenar ordenar = new Ordenar();

	/**
	 * 
	 * @param n
	 */
	public void Ordena(int n) {

		int v[] = new int[n];
		for (int i = 0; i < n; i++) {
			v[i] = (int) (Math.random() * n);
		}

		System.out.println("Ordena��o em InsertSort");
		double tempoInicio = System.currentTimeMillis();
		ordenar.insertSort(v);
		System.out.println("Tempo Total: " + (System.currentTimeMillis() - tempoInicio));
		// System.out.println(Arrays.toString(v));

		System.out.println("\nOrdena��o em SelectionSort");
		double tempoInicio2 = System.currentTimeMillis();
		ordenar.selectionSort(v);
		System.out.println("Tempo Total: " + (System.currentTimeMillis() - tempoInicio2));
		// System.out.println(Arrays.toString(v));

		System.out.println("\nOrdena��o em BubbleSort");
		double tempoInicio3 = System.currentTimeMillis();
		ordenar.bubbleSort(v);
		System.out.println("Tempo Total: " + (System.currentTimeMillis() - tempoInicio3));
//		System.out.println(Arrays.toString(v));

	}

}
