package Testes;

import java.util.Arrays;
import classes.Ordenar;

public class Questao3 {

	Ordenar ordenar = new Ordenar();

	/**
	 * 
	 * @param n
	 */
	public void PiorCaso(int n) {

		int[] numeros = new int[n];
		int aux = 0;

		for (int i = n; i > 0; i--) {
			numeros[aux] = i;
			aux++;

		}
		System.out.println("Ordena��o em InsertSort");
		double tempoInicio = System.currentTimeMillis();
		ordenar.insertSort(numeros);
		System.out.println("Tempo Total: " + (System.currentTimeMillis() - tempoInicio));
//		System.out.println(Arrays.toString(numeros));

		System.out.println("\nOrdena��o em SelectionSort");
		double tempoInicio2 = System.currentTimeMillis();
		ordenar.selectionSort(numeros);
		System.out.println("Tempo Total: " + (System.currentTimeMillis() - tempoInicio2));
		// System.out.println(Arrays.toString(numeros));

		System.out.println("\nOrdena��o em BubbleSort");
		double tempoInicio3 = System.currentTimeMillis();
		ordenar.bubbleSort(numeros);
		System.out.println("Tempo Total: " + (System.currentTimeMillis() - tempoInicio3));
		// System.out.println(Arrays.toString(numeros));

	}

	/**
	 * 
	 * @param n
	 */

	public void MelhorCaso(int n) {
		int[] numeros = new int[n];

		for (int i = 0; i < n; i++) {
			numeros[i] = i;

		}
		System.out.println("Ordena��o em InsertSort");
		double tempoInicio = System.currentTimeMillis();
		ordenar.insertSort(numeros);
		System.out.println("Tempo Total: " + (System.currentTimeMillis() - tempoInicio));
//		System.out.println(Arrays.toString(numeros));

		System.out.println("\nOrdena��o em SelectionSort");
		double tempoInicio2 = System.currentTimeMillis();
		ordenar.selectionSort(numeros);
		System.out.println("Tempo Total: " + (System.currentTimeMillis() - tempoInicio2));
		// System.out.println(Arrays.toString(numeros));

		System.out.println("\nOrdena��o em BubbleSort");
		double tempoInicio3 = System.currentTimeMillis();
		ordenar.bubbleSort(numeros);
		System.out.println("Tempo Total: " + (System.currentTimeMillis() - tempoInicio3));
		// System.out.println(Arrays.toString(numeros));

	}

}
