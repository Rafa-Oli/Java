package classes;

//Questao1
public class Ordenar {
	/**
	 * 
	 * @param v
	 */

	public void insertSort(int[] v) {

		int x, j;
		for (int i = 1; i < v.length; i++) {
			x = v[i];
			j = i - 1;
			while ((j >= 0) && v[j] > x) {
				v[j + 1] = v[j];
				j = j - 1;

			}
			v[j + 1] = x;

		}

	}

	/**
	 * 
	 * @param v
	 */
	public void selectionSort(int[] v) {
		for (int i = 0; i < v.length; i++) {
			int menor = i;
			for (int j = i + 1; j < v.length; j++) {
				if (v[j] < v[menor]) {

					menor = j;
				}

			}
			trocar(v, i, menor);
		}
	}

	/**
	 * 
	 * @param v
	 * @param i
	 * @param menor
	 */
	private static void trocar(int[] v, int i, int menor) {
		int aux = v[i];
		v[i] = v[menor];
		v[menor] = aux;

	}

	/**
	 * 
	 * @param v
	 */
	public void bubbleSort(int[] v) {
		int aux = 0;
		for (int i = 0; i < v.length - 1; i++) {
			for (int j = 0; j < v.length - i - 1; j++) {
				if (v[j] > v[j + 1]) {
					aux = v[j];
					v[j] = v[j + 1];
					v[j + 1] = aux;
				}
			}
		}

	}

}
