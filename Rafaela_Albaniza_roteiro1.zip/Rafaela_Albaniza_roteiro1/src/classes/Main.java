package classes;

import java.util.Arrays;

import Testes.Questao2;
import Testes.Questao3;

public class Main {
	public static void main(String[] args) {
		Questao3 q3 = new Questao3();
		Ordenar ordenar = new Ordenar();

//-------------Questao 2 - letra A	
//	System.out.println("Ordena��o para 1000 rand�micos\n");
//	Questao2 letraA= new Questao2();
//	letraA.Ordena(1000);

//---------------Questao 2 - letra b
//	System.out.println("\nOrdena��o para 10000 rand�micos\n");
//	Questao2 letraB = new Questao2();
//	letraB.Ordena(10000);

//----------------Questao 2- letra c

//	System.out.println("Ordena��o para 100000 rand�micos\n");
//	Questao2 letraC = new Questao2();
//	letraC.Ordena(100000);
//

//----------------Questao 2- letra d
//	System.out.println("Ordena��o para 1000000 rand�micos\n");
//	Questao2 letraD = new Questao2();
//	letraD.Ordenar(1000000);

//-----------Questao 3 -

		// q3.PiorCaso(1000);
		// q3.PiorCaso(10000);
		// q3.PiorCaso(100000);

		// q3.MelhorCaso(1000);
		// q3.MelhorCaso(10000);
		// q3.MelhorCaso(100000);

	}
}
